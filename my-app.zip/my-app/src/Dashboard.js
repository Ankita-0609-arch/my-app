import React from "react";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();
  const handleCardClick = () => {
    navigate("/map");
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <div onClick={handleCardClick} style={{ border: "1px solid black", padding: "20px", cursor: "pointer" }}>
        Open Map View
      </div>
    </div>
  );
};

export default Dashboard;
